int tick;
int tick1;
unsigned int sensor_voltage;







void initialize();
void interrupt();

void stop_moving();
void move_left();
void move_right();
void move_forward();
void move_backwards();


void position();
void check_and_stop();

void msDelay(int x);

void ATD_init();
unsigned int ATD_read_A0();

void check_right();
void check_left();
void check_front();
void CCPPWM_init(void);
void LEDS(unsigned int Britness);

void main() {
     initialize();
     CCPPWM_init();
     ATD_init();
     while(1){

              check_right();
              check_left();
              check_front();

              position();

              check_and_stop();
 }
}



void initialize(){
   TRISC = 0x00; //All PORTC pins is output
   TRISB = 0b11111101; //All PORTB pins is input exept b1
   TRISA = 0x01; //A0 pin is input
   TRISD = 0b00000000; //All PORTD pins output





   OPTION_REG= 0x87;//Internal clock Fosc/4, prescaler of 256 , TMR0
   //0.5uS* 256 = 128uS (per increment)
   TMR0=248;// 8* 128uS = 1ms

   INTCON = 0b11100000; //GIE , T0IE, peripheral interrupt

   T1CON=0x01;// Timer1
   TMR1H=0;
   TMR1L=0;




}





void interrupt(){
    if(INTCON & 0x04){// TMR0 Overflow interrupt, will get here every 1ms
       TMR0=248;
       tick++;
       tick1++;
       INTCON = INTCON & 0xFB;//Clear T0IF
       }

}




void ATD_init(){
ADCON0 = 0x41; // ATD ON, channel 0, fosc/16
ADCON1 = 0xCE; //  A0 is analoge
}

unsigned int ATD_read_A0(){
ADCON0 = ADCON0 | 0x04;
while(ADCON0 & 0x04);
return ((ADRESH<<8) | ADRESL);  // rutern the value of sensor
}


void msDelay(int const x){
       tick=0;
       while(tick<x);


}

 void check_right(){
 // read B4 : right Ldr sensor
if(!(PORTB & 0b00010000)){
    tick1 = 0;

    // read  B7 : front sensor
    while((PORTB & 0b10000000)){

        if (tick1 >= 5000) break;
    move_right();

    }
stop_moving();
}


 }
void check_left(){
// read B5 : left LDR sensor
if (!(PORTB & 0b00100000)){
     tick1 = 0;
    // read  B7 : front sensor until
    while((PORTB & 0b10000000)){
      if (tick1 >= 5000) break;
      move_left();
      }
stop_moving();
}
}

void check_front(){
sensor_voltage = ATD_read_A0();

 while(sensor_voltage >= 80 && sensor_voltage <= 307){
 sensor_voltage = ATD_read_A0();
 move_forward();
 }
 stop_moving();
}

void stop_moving(){
     PORTC = PORTC & 0b00001111;
}


void move_left(){
      PORTC = (PORTC & 0b00001111)| 0b01100000;
}

void move_right(){
   PORTC = (PORTC & 0b00001111) | 0b10010000;
}

void move_forward(){
     PORTC = (PORTC & 0b00001111)| 0b10100000;

}

void move_backwards(){
     PORTC = (PORTC & 0b00001111)| 0b01010000;
}



void position(){
     sensor_voltage = ATD_read_A0();
     while(sensor_voltage < 75){
     move_backwards();
     sensor_voltage = ATD_read_A0();
}
stop_moving();
}

void check_and_stop(){
 sensor_voltage = ATD_read_A0();
 while (!(PORTB & 0b10000000))
 {
       if(sensor_voltage < 80 || sensor_voltage > 307) break;

       LEDS(25);
       LEDS(125);
       LEDS(250);
 }
LEDS(0);

}



void CCPPWM_init(void){ //Configure CCP1 and CCP2 at 2ms period with 50% duty cycle
  T2CON =  0b00000111;//enable Timer2 at Fosc/4 with 1:16 prescaler (8 uS percount 2000uS to count 250 counts)
  CCP2CON = 0x0C;//enable PWM for CCP2

  PR2 = 250;// 250 counts =8uS *250 =2ms period
  CCPR2L= 0;


}

void LEDS(unsigned int Britness){
      CCPR2L=Britness;
}